import torch
from transformers import AutoModelForCausalLM, AutoTokenizer, AutoConfig
import os
import json

with open("verilog_designs.json",'r') as f:  #load  verilog_designs 
    json_data = f.read()

data = json.loads(json_data) # convert the json data

os.environ['HF_TOKEN']="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"
os.environ['HUGGINGFACEHUB_API_TOKEN']="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"
os.environ['HF_HOME'] = "/scratch/bcfk/vpulavarthi/cache"
os.environ['HF_HUB_CACHE'] = "/scratch/bcfk/vpulavarthi/cache"


device = 'cuda'
model_path = "ibm-granite/granite-3b-code-base"

tokenizer = AutoTokenizer.from_pretrained(model_path)

# drop device_map if running on CPU
model = AutoModelForCausalLM.from_pretrained(model_path, device_map=device)
model.eval()

for x in data:
    input_text = """
            You are an expert in SystemVerilog Assertions.
        Your task is to generate the list of assertions to the given verilog design. An example is shown below. Generate only the list of assertions for the test program with no additional text.
        Program 1: " module arb2(clk, rst, req1, req2, gnt1, gnt2); input clk, rst; input req1, req2; output gnt1, gnt2; reg state; reg gnt1, gnt2; always @ (posedge clk or posedge rst) if (rst) state <= 0; else state <= gnt1; always @ (*) if (state) begin gnt1 = req1 & ~req2; gnt2 = req2; end else begin gnt1 = req1; gnt2 = req2 & ~req1; end endmodule"
        Assertions 1: (state == 1 & req2 == 1) |-> (gnt1 == 0);(req1 == 1 & state == 0) |-> (gnt1 == 1);(req1 == 0) |-> (gnt1 == 0);(req1 == 1 & req2 == 0) |-> (gnt1 == 1);(req1 == 1 & state == 0) |-> (gnt2 == 0);(req2 == 1 & state == 1) |-> (gnt2 == 1);(req2 == 0) |-> (gnt2 == 0);(req2 == 1 & req1 == 0) |-> (gnt2 == 1); (gnt2) |-> (req2); (gnt1) |-> (req1); 
        Test Program:            
            """ + f"""{x["verilog_design"]}\n""" + "Test Assertions:"
    # tokenize the text
    #print(input_text)
    input_tokens = tokenizer(input_text, return_tensors="pt")
    # transfer tokenized inputs to the device
    for i in input_tokens:
        input_tokens[i] = input_tokens[i].to(device)
    # generate output tokens
    output = model.generate(**input_tokens,max_new_tokens=1024)
    # decode output tokens into text
    output = tokenizer.batch_decode(output)
    # loop over the batch to print, in this example the batch size is 1

    #print(output)
    #for i in output:
    #    print(i)
    x["assertions_granite_3b"] = output[len(input_text):]

final_data = json.dumps(data)
with open("final_assertions_granite_3b.json", 'w') as file:
    file.write(final_data)


